#include "CallbackController.h"
#include <cstdlib>  // Para std::atoi e std::atof

// Inicialização do buffer estático
String CallbackController::uartBuffer = "";
SemaphoreHandle_t CallbackController::uartMutex = nullptr;

void CallbackController::digitalWrite(sc_integer pin, sc_integer value) {
    Serial.print(millis());
    Serial.print(" ms - digitalWrite chamado: ");
    Serial.print(pin);
    Serial.print(" = ");
    Serial.println(value);
    ::digitalWrite(pin, value);
}

void CallbackController::pinMode(sc_integer pin, sc_integer mode) {
    Serial.print("pinMode chamado: ");
    Serial.print(pin);
    Serial.print(" = ");
    Serial.println(mode);
    
    if (mode > 0) {
        ::pinMode(pin, OUTPUT);
    } else {
        ::pinMode(pin, INPUT);
    }
}

void CallbackController::UART_config() {
    Serial.begin(115200);  // Inicializa a UART com 115200 bps
    while (!Serial) {
        ; // Aguarda a inicialização
    }
    Serial.println("UART inicializada com sucesso!");
}

void CallbackController::UART_print(sc_string mensagem) {
    if (uartMutex && xSemaphoreTakeRecursive(uartMutex, portMAX_DELAY)) {
        Serial.println(mensagem);
        xSemaphoreGiveRecursive(uartMutex);
    }
}

sc_string CallbackController::UART_read() {
    if (uartMutex && xSemaphoreTakeRecursive(uartMutex, portMAX_DELAY)) {
        while (Serial.available()) {
            char c = Serial.read();
            if (c == '\n') {
                String result = uartBuffer;
                uartBuffer = "";
                result.trim();
                Serial.println(result.c_str());
                xSemaphoreGiveRecursive(uartMutex);
                return strdup(result.c_str());
            } else {
                uartBuffer += c;
            }
        }
        xSemaphoreGiveRecursive(uartMutex);
    }
    return strdup("");
}

/*sc_integer CallbackController::UART_read_int() {
    while (Serial.available()) {
        char c = Serial.read();
        
        if (c == '\n') { // Fim da linha
            String result = uartBuffer;
            uartBuffer = "";
            result.trim();
            
            // Verificar se a string contém apenas números
            bool isValid = true;
            if (result.length() == 0) {
                isValid = false;
            } else {
                for (int i = 0; i < result.length(); i++) {
                    if (!isDigit(result.charAt(i))) {
                        isValid = false;
                        break;
                    }
                }
            }
            
            if (isValid) {
                int value = result.toInt();
                
                // Validar limites (ajuste conforme necessário)
                if (value > 0 && value <= 10000) {
                    Serial.printf("Número válido recebido: %d\n", value);
                    return value;
                } else {
                    Serial.println("Erro: Número fora do limite (1-10000)!");
                    return -1;
                }
            } else {
                Serial.println("Erro: Digite apenas números!");
                return -1; // Valor de erro
            }
            
        } else if (isDigit(c)) {
            // Aceitar apenas dígitos (máximo 5 caracteres para evitar overflow)
            if (uartBuffer.length() < 5) {
                uartBuffer += c;
            } else {
                Serial.println("Número muito longo! Máximo 5 dígitos.");
            }
        } else {
            // Ignorar caracteres não numéricos (exceto \n)
            Serial.println("Caractere inválido ignorado. Digite apenas números.");
        }
    }
    
    return 0; // Nenhum dado completo disponível
}*/

sc_integer CallbackController::stringParaInteiro(sc_string mensagem) {
    if (mensagem == nullptr) {
        return 0; // Valor padrão em caso de ponteiro nulo
    }
    return static_cast<sc_integer>(std::atoi(mensagem));
}

sc_real CallbackController::stringParaReal(sc_string mensagem) {
    if (mensagem == nullptr) {
        return 0.0; // Valor padrão em caso de ponteiro nulo
    }
    return static_cast<sc_real>(std::atof(mensagem));
}

void CallbackController::initMutex() {
    if (uartMutex == nullptr) {
        uartMutex = xSemaphoreCreateRecursiveMutex();
    }
}