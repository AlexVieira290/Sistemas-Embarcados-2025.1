#include "Statechart.h"

// Instância da máquina de estados
Statechart statechart;

void setup() {
    // Se você configurou pinos via pinMode() no próprio itemis, não precisa repetir aqui

    statechart.enter();           // inicia a máquina de estados
    statechart.raise_toggle();    // ou outro evento de inicialização, se aplicável
}

void loop() {
    statechart.runCycle();        // executa ciclos da máquina
    delay(1);                     // espera mínima
}