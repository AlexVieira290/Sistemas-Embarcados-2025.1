#ifndef CALLBACKCONTROLLER_H
#define CALLBACKCONTROLLER_H

#include "src-gen/Statechart.h"
#include <Arduino.h>
#include "freertos/semphr.h"

class CallbackController : public Statechart::OperationCallback {
public:
    // Métodos para controle de GPIO
    void digitalWrite(sc_integer pin, sc_integer value) override;
    void pinMode(sc_integer pin, sc_integer mode) override;

    // Métodos para controle de UART
    void UART_config() override;
    void UART_print(sc_string mensagem) override;
    sc_string UART_read() override;
    //sc_integer UART_read_int() override;
    sc_integer stringParaInteiro(sc_string mensagem) override;
    sc_real stringParaReal(sc_string mensagem) override;
    void initMutex();  // Inicializa o mutex, deve ser chamado no setup

private:
    static String uartBuffer; // Buffer estático para leitura UART
    static SemaphoreHandle_t uartMutex;
};

#endif // CALLBACKCONTROLLER_H
